# ቡና ቤተሰብ ሩጫ · Ticket Finder + Admin

## Replit ላይ እንዴት ማስገባት

1. [replit.com](https://replit.com) ላይ **Create Repl** → **Import from GitHub** ወይም **Upload** ይህን ፎልደር
2. Shell ውስጥ፦
   ```
   npm install
   npm start
   ```
3. **Run** ይጫኑ

## Admin

- URL: `https://YOUR-REPL.replit.app/admin`
- Default password: **`bunna2026`**
- በ Replit **Secrets** ላይ ያስቀምጡ፦
  - `ADMIN_PASSWORD` = የእርስዎ ጠንካራ የይለፍ ቃል
  - `SESSION_SECRET` = ማንኛውም ረጅም ሚስጥራዊ ቃል

## ችሎታዎች

| ባህሪ | መግለጫ |
|------|--------|
| ዋና ገጽ | ትኬት ወኪሎች ፍለጋ |
| አድሚን | ፖስት መፍጠር / ማርትዕ / መሰረዝ |
| ፎቶ | ከስልክ/ኮምፒውተር ማስገባት |
| ህዝብ | ፖስት ሲወጣ ሁሉም በዋና ገጽ ያያል |

## አስፈላጊ

Replit **Always On** ወይም Deployment ካላደረጉ free tier ላይ ሲያልቅ ሊቆም ይችላል።  
ፎቶዎች `uploads/` ውስጥ ይቀመጣሉ — Replit ካቆመ/ከተጣራ ሊጠፉ ይችላሉ። ለቋሚነት Object Storage ያስቡ።
