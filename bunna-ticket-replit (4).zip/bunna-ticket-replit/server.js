const express = require("express");
const session = require("express-session");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "bunna2026";
const DATA_FILE = path.join(__dirname, "data", "posts.json");
const UPLOADS = path.join(__dirname, "uploads");

if (!fs.existsSync(UPLOADS)) fs.mkdirSync(UPLOADS, { recursive: true });
if (!fs.existsSync(path.dirname(DATA_FILE))) fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, "[]");

function readPosts() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  } catch {
    return [];
  }
}
function writePosts(posts) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(posts, null, 2));
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase() || ".jpg";
    cb(null, Date.now() + "-" + crypto.randomBytes(4).toString("hex") + ext);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (/^image\//.test(file.mimetype)) cb(null, true);
    else cb(new Error("Only images allowed"));
  },
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(
  session({
    secret: process.env.SESSION_SECRET || "bunna-family-run-secret-change-me",
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 7 * 24 * 60 * 60 * 1000 },
  })
);
app.use("/uploads", express.static(UPLOADS));
app.use(express.static(path.join(__dirname, "public")));

function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin) return next();
  return res.status(401).json({ error: "Unauthorized" });
}

// ---- Auth ----
app.post("/api/login", (req, res) => {
  const { password } = req.body || {};
  if (password && password === ADMIN_PASSWORD) {
    req.session.isAdmin = true;
    return res.json({ ok: true });
  }
  return res.status(401).json({ error: "Wrong password" });
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get("/api/me", (req, res) => {
  res.json({ isAdmin: !!(req.session && req.session.isAdmin) });
});

// ---- Public posts ----
app.get("/api/posts", (_req, res) => {
  const posts = readPosts()
    .filter((p) => p.published !== false)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(posts);
});

// ---- Admin posts CRUD ----
app.get("/api/admin/posts", requireAdmin, (_req, res) => {
  const posts = readPosts().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(posts);
});

app.post("/api/admin/posts", requireAdmin, upload.single("photo"), (req, res) => {
  const posts = readPosts();
  const id = crypto.randomBytes(8).toString("hex");
  const post = {
    id,
    title: (req.body.title || "").trim(),
    body: (req.body.body || "").trim(),
    photo: req.file ? "/uploads/" + req.file.filename : null,
    published: req.body.published !== "false",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  posts.push(post);
  writePosts(posts);
  res.json(post);
});

app.put("/api/admin/posts/:id", requireAdmin, upload.single("photo"), (req, res) => {
  const posts = readPosts();
  const i = posts.findIndex((p) => p.id === req.params.id);
  if (i < 0) return res.status(404).json({ error: "Not found" });
  const old = posts[i];
  posts[i] = {
    ...old,
    title: req.body.title !== undefined ? String(req.body.title).trim() : old.title,
    body: req.body.body !== undefined ? String(req.body.body).trim() : old.body,
    published: req.body.published !== undefined ? req.body.published !== "false" : old.published,
    photo: req.file ? "/uploads/" + req.file.filename : old.photo,
    updatedAt: new Date().toISOString(),
  };
  // optional: delete old photo if replaced
  if (req.file && old.photo) {
    const oldPath = path.join(__dirname, old.photo.replace(/^\//, ""));
    fs.unlink(oldPath, () => {});
  }
  writePosts(posts);
  res.json(posts[i]);
});

app.delete("/api/admin/posts/:id", requireAdmin, (req, res) => {
  let posts = readPosts();
  const post = posts.find((p) => p.id === req.params.id);
  if (!post) return res.status(404).json({ error: "Not found" });
  if (post.photo) {
    const p = path.join(__dirname, post.photo.replace(/^\//, ""));
    fs.unlink(p, () => {});
  }
  posts = posts.filter((p) => p.id !== req.params.id);
  writePosts(posts);
  res.json({ ok: true });
});

app.get("/admin", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "admin.html"));
});

app.listen(PORT, "0.0.0.0", () => {
  console.log("Bunna Ticket + Admin running on port", PORT);
  console.log("Admin password: set ADMIN_PASSWORD env (default bunna2026)");
});
